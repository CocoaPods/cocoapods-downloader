module Pod
  module Downloader
    # @return [String] Downloader’s version, following
    #         [semver](http://semver.org).
    #
    VERSION = '0.6.1'
  end
end
